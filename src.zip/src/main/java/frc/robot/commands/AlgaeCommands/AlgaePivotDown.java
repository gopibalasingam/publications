package frc.robot.commands.AlgaeCommands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants.AlgaeConstants;
import frc.robot.subsystems.AlgaeEndeffactorSubsystem;

/**
 * Command to pivot the algae mechanism to the down position.
 * 
 * <p>This command moves the algae pivot to the down position for ground pickup.
 * The pivot uses PID control to reach and maintain the setpoint.
 * 
 * <p><b>For Beginners:</b> The "down" position is used to pick up algae
 * game pieces from the ground. The mechanism will automatically move
 * to this angle and hold it there.
 * 
 * @author FRC Team 9569
 */
public class AlgaePivotDown extends Command {
    private final AlgaeEndeffactorSubsystem algaeEndeffactorSubsystem;

    /**
     * Creates a new AlgaePivotDown command.
     * 
     * @param algaeEndeffactorSubsystem The algae subsystem to control
     */
    public AlgaePivotDown(AlgaeEndeffactorSubsystem algaeEndeffactorSubsystem) {
        this.algaeEndeffactorSubsystem = algaeEndeffactorSubsystem;
        addRequirements(algaeEndeffactorSubsystem);
    }
    
    /**
     * Called once when the command is initially scheduled.
     * Currently no initialization needed.
     */
    @Override
    public void initialize() {
    }

    /**
     * Called repeatedly while the command is scheduled.
     * Continuously moves the pivot to the down position.
     */
    @Override
    public void execute() {
        algaeEndeffactorSubsystem.algaeSetPoint(AlgaeConstants.PIVOT_DOWN_POSITION);
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * Stops the pivot motor.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        algaeEndeffactorSubsystem.algaePivotStop();
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * @return false - command runs until interrupted
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}
