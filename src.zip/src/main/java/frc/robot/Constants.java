package frc.robot;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.util.Units;

/**
 * Central repository for all robot constants.
 * 
 * <p>This class organizes constants into logical groups using nested static classes.
 * Each inner class represents a specific subsystem or functional area of the robot.
 * Constants are immutable (final) to prevent accidental modification.
 * 
 * <p><b>Beginner Note:</b> Constants are values that don't change during robot operation,
 * like motor IDs, speed limits, and field positions.
 */
public final class Constants {

    /**
     * Constants for operator input devices.
     * These control how the driver interacts with the robot.
     */
    public static final class OperatorConstants {
        /** USB port number for the primary driver controller. */
        public static final int DRIVER_CONTROLLER_PORT = 2;
        
        /** USB port number for the secondary operator controller. */
        public static final int OPERATOR_CONTROLLER_PORT = 1;
        
        /** Joystick deadband threshold to prevent drift (0.0 to 1.0). */
        public static final double JOYSTICK_DEADBAND = 0.1;
        
        /** Rotation speed multiplier for fine control (0.0 to 1.0). */
        public static final double TURN_SPEED_FACTOR = 0.5;
    }

    /**
     * Constants for the swerve drive system.
     * Controls robot movement and speed limits.
     */
    public static final class SwerveConstants {
        /** Maximum linear speed in meters per second. */
        public static final double MAX_SPEED_METERS_PER_SECOND = Units.feetToMeters(10.5);
        
        /** Translation scaling factor for driver input (0.0 to 1.0). */
        public static final double TRANSLATION_SCALE_FACTOR = 1.0;
    }

    /**
     * Hardware port mappings for all motors and sensors.
     * These CAN IDs and DIO ports must match the physical robot wiring.
     */
    public static final class HardwareMap {
        /** CAN ID for left elevator motor. */
        public static final int ELEVATOR_MOTOR_LEFT_ID = 40;
        
        /** CAN ID for right elevator motor. */
        public static final int ELEVATOR_MOTOR_RIGHT_ID = 41;
        
        /** CAN ID for left coral intake motor. */
        public static final int CORAL_MOTOR_LEFT_ID = 53;
        
        /** CAN ID for right coral intake motor. */
        public static final int CORAL_MOTOR_RIGHT_ID = 52;
        
        /** DIO port for outer coral beam break sensor. */
        public static final int BEAM_BREAK_OUTER_PORT = 9;
        
        /** DIO port for inner coral beam break sensor. */
        public static final int BEAM_BREAK_INNER_PORT = 8;
        
        /** CAN ID for algae intake motor. */
        public static final int ALGAE_MOTOR_ID = 38;
        
        /** CAN ID for algae pivot motor. */
        public static final int ALGAE_PIVOT_MOTOR_ID = 39;
        
        /** DIO port for algae duty cycle encoder. */
        public static final int ALGAE_ENCODER_PORT = 7;
        
        /** PWM port for LED strip. */
        public static final int LED_STRIP_PORT = 9;
        
        /** Number of LEDs in the strip. */
        public static final int LED_COUNT = 210;
    }

    /**
     * Elevator subsystem position setpoints.
     * These values represent encoder positions for different scoring heights.
     */
    public static final class ElevatorConstants {
        /** Level 3 position (highest scoring position) in encoder ticks. */
        public static final double LEVEL_3_POSITION = 880.0;
        
        /** Level 2 position (middle scoring position) in encoder ticks. */
        public static final double LEVEL_2_POSITION = 250.0;
        
        /** Level 1 position (lowest scoring position) in encoder ticks. */
        public static final double LEVEL_1_POSITION = 30.0;
        
        /** Zero position (fully retracted) in encoder ticks. */
        public static final double ZERO_POSITION = 25.0;
        
        /** PID proportional gain for elevator position control. */
        public static final double POSITION_KP = 0.05;
        
        /** PID integral gain for elevator position control. */
        public static final double POSITION_KI = 0.0;
        
        /** PID derivative gain for elevator position control. */
        public static final double POSITION_KD = 0.0;
        
        /** Feedforward static gain (kS) in volts. */
        public static final double FEEDFORWARD_KS = 0.2;
        
        /** Feedforward gravity gain (kG) in volts. */
        public static final double FEEDFORWARD_KG = 0.24;
        
        /** Feedforward velocity gain (kV) in volts per (meter per second). */
        public static final double FEEDFORWARD_KV = 8.97;
        
        /** Feedforward acceleration gain (kA) in volts per (meter per second squared). */
        public static final double FEEDFORWARD_KA = 0.02;
    }

    /**
     * Algae subsystem constants.
     * Controls the algae intake mechanism and pivot positions.
     */
    public static final class AlgaeConstants {
        /** Encoder zero offset for absolute positioning. */
        public static final double ENCODER_ZERO_OFFSET = 0.54;
        
        /** PID proportional gain for pivot position control. */
        public static final double PIVOT_KP = 6.0;
        
        /** PID integral gain for pivot position control. */
        public static final double PIVOT_KI = 0.0;
        
        /** PID derivative gain for pivot position control. */
        public static final double PIVOT_KD = 0.0;
        
        /** Intake motor voltage for pulling in algae. */
        public static final double INTAKE_VOLTAGE = -12.0;
        
        /** Eject motor voltage for expelling algae. */
        public static final double EJECT_VOLTAGE = 12.0;
        
        /** Pivot position for fully down (ground pickup). */
        public static final double PIVOT_DOWN_POSITION = 0.0;
        
        /** Pivot position for middle height. */
        public static final double PIVOT_MIDDLE_POSITION = -0.11;
        
        /** Pivot position for up (scoring height). */
        public static final double PIVOT_UP_POSITION = -0.25;
        
        /** Pivot position for upper (highest scoring). */
        public static final double PIVOT_UPPER_POSITION = -0.36;
    }

    /**
     * Coral subsystem constants.
     * Controls the coral intake mechanism and differential speed ratios.
     */
    public static final class CoralConstants {
        /** Normal intake voltage for both motors. */
        public static final double INTAKE_VOLTAGE = 12.0;
        
        /** Slow intake voltage when object detected. */
        public static final double SLOW_INTAKE_VOLTAGE = 4.0;
        
        /** Eject voltage for both motors. */
        public static final double EJECT_VOLTAGE = -12.0;
        
        /** Full speed differential ratio. */
        public static final double DIFF_FULL_SPEED = 1.0;
        
        /** Reduced speed differential ratio for turning. */
        public static final double DIFF_REDUCED_SPEED = 0.4;
    }

    /**
     * Auto-alignment coordinates for field positions.
     * Contains preset poses for autonomous alignment to scoring locations.
     * Separated by alliance color (Left = Blue, Right = Red).
     */
    public static final class AutoAlignCoordinates {

        /**
         * Blue alliance (left side) alignment positions.
         * These are field positions in meters with rotation in radians.
         */
        public static final class BlueAlliance {
            public static final Pose2d POSITION_6 = new Pose2d(13.65, 2.8, Rotation2d.fromDegrees(-60));
            public static final Pose2d POSITION_7 = new Pose2d(14.38, 3.91, Rotation2d.fromDegrees(0));
            public static final Pose2d POSITION_8 = new Pose2d(13.84, 5.14, Rotation2d.fromDegrees(60));
            public static final Pose2d POSITION_9 = new Pose2d(12.54, 5.2, Rotation2d.fromDegrees(120));
            public static final Pose2d POSITION_10 = new Pose2d(11.74, 4.14, Rotation2d.fromDegrees(180));
            public static final Pose2d POSITION_11 = new Pose2d(12.30, 2.98, Rotation2d.fromDegrees(-120));
            public static final Pose2d POSITION_17 = new Pose2d(3.92, 2.83, Rotation2d.fromDegrees(-120));
            public static final Pose2d POSITION_18 = new Pose2d(3.09, 4.01, Rotation2d.fromDegrees(180));
            public static final Pose2d POSITION_19 = new Pose2d(3.76, 4.98, Rotation2d.fromDegrees(120));
            public static final Pose2d POSITION_20 = new Pose2d(5.0, 5.17, Rotation2d.fromDegrees(60));
            public static final Pose2d POSITION_21 = new Pose2d(5.84, 4.14, Rotation2d.fromDegrees(0));
            public static final Pose2d POSITION_22 = new Pose2d(5.293, 2.983, Rotation2d.fromDegrees(-60));
        }

        /**
         * Red alliance (right side) alignment positions.
         * These are field positions in meters with rotation in radians.
         */
        public static final class RedAlliance {
            public static final Pose2d POSITION_6 = new Pose2d(13.90, 2.96, Rotation2d.fromDegrees(-60));
            public static final Pose2d POSITION_7 = new Pose2d(14.38, 4.18, Rotation2d.fromDegrees(0));
            public static final Pose2d POSITION_8 = new Pose2d(13.57, 5.24, Rotation2d.fromDegrees(60));
            public static final Pose2d POSITION_9 = new Pose2d(12.26, 5.07, Rotation2d.fromDegrees(120));
            public static final Pose2d POSITION_10 = new Pose2d(11.74, 3.85, Rotation2d.fromDegrees(180));
            public static final Pose2d POSITION_11 = new Pose2d(12.56, 2.8, Rotation2d.fromDegrees(-120));
            public static final Pose2d POSITION_17 = new Pose2d(4.27, 2.69, Rotation2d.fromDegrees(-120));
            public static final Pose2d POSITION_18 = new Pose2d(3.117, 3.545, Rotation2d.fromDegrees(180));
            public static final Pose2d POSITION_19 = new Pose2d(3.42, 4.89, Rotation2d.fromDegrees(120));
            public static final Pose2d POSITION_20 = new Pose2d(4.72, 5.37, Rotation2d.fromDegrees(60));
            public static final Pose2d POSITION_21 = new Pose2d(5.83, 4.52, Rotation2d.fromDegrees(0));
            public static final Pose2d POSITION_22 = new Pose2d(5.19, 2.9, Rotation2d.fromDegrees(-60));
        }
    }
    
    private Constants() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}