package frc.robot.commands.AlgaeCommands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants.AlgaeConstants;
import frc.robot.subsystems.AlgaeEndeffactorSubsystem;

/**
 * Command to eject algae game pieces.
 * 
 * <p>This command runs the algae intake motors in reverse to expel algae from the robot.
 * The command continues until manually stopped by releasing the button.
 * 
 * <p><b>For Beginners:</b> This command makes the algae intake spin outward
 * to push algae out of the robot. It runs continuously while you hold the button.
 * 
 * @author FRC Team 9569
 */
public class AlgaeEject extends Command {
    private final AlgaeEndeffactorSubsystem algaeSubsystem;

    /**
     * Creates a new AlgaeEject command.
     * 
     * @param algaeSubsystem The algae end effector subsystem to control
     */
    public AlgaeEject(AlgaeEndeffactorSubsystem algaeSubsystem) {
        this.algaeSubsystem = algaeSubsystem;
        addRequirements(algaeSubsystem);
    }
    
    /**
     * Called once when the command is initially scheduled.
     */
    @Override
    public void initialize() {
        algaeSubsystem.setIntakeSpeed(AlgaeConstants.EJECT_VOLTAGE);
    }

    /**
     * Called repeatedly while the command is scheduled.
     */
    @Override
    public void execute() {
        algaeSubsystem.setIntakeSpeed(AlgaeConstants.EJECT_VOLTAGE);
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        algaeSubsystem.stopIntake();
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * @return false - command runs until interrupted
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}
