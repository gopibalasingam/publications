package frc.robot.commands.ElevatorCommands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.ElevatorSubsystem;

/**
 * Command to cycle the elevator through its levels.
 * 
 * <p>This command moves the elevator up or down one level based on the direction.
 * It schedules the appropriate level command (L3, L2, or Zero) based on
 * the current level and direction.
 * 
 * <p>Valid levels are:
 * <ul>
 * <li>0 or 1: Zero/retracted position</li>
 * <li>2: Level 2 position</li>
 * <li>3: Level 3 position</li>
 * </ul>
 * 
 * <p><b>For Beginners:</b> This command lets you move the elevator
 * up or down one level at a time using a single button. Pass +1 to go up,
 * or -1 to go down. The command handles the logic of which position to move to.
 * 
 * <p><b>Usage Example:</b>
 * <pre>
 * // Create buttons to cycle elevator up and down
 * new JoystickButton(controller, Button.kRightBumper.value)
 *     .onTrue(new ElevatorCycle(elevatorSubsystem, 1));  // Cycle up
 * new JoystickButton(controller, Button.kLeftBumper.value)
 *     .onTrue(new ElevatorCycle(elevatorSubsystem, -1)); // Cycle down
 * </pre>
 * 
 * @author FRC Team 9569
 */
public class ElevatorCycle extends Command {
    private final ElevatorSubsystem elevatorSubsystem;
    private final double direction;

    /**
     * Creates a new ElevatorCycle command.
     * 
     * @param elevatorSubsystem The elevator subsystem to control
     * @param direction Direction to cycle: +1 for up, -1 for down
     */
    public ElevatorCycle(ElevatorSubsystem elevatorSubsystem, double direction) {
        this.elevatorSubsystem = elevatorSubsystem;
        this.direction = direction;
        addRequirements(elevatorSubsystem);
    }

    /**
     * Called once when the command is initially scheduled.
     * 
     * <p>Calculates the target level and schedules the appropriate command.
     * Clamps levels between 0 and 3 to prevent invalid positions.
     */
    @Override
    public void initialize() {
        int currentLevel = elevatorSubsystem.getLevel();
        int targetLevel = currentLevel + (int) direction;
        
        // Create and schedule the appropriate level command
        Command levelCommand;
        
        // Clamp level between 0 and 3
        if (targetLevel >= 3) {
            levelCommand = new ElevatorL3Command(elevatorSubsystem);
        } else if (targetLevel == 2) {
            levelCommand = new ElevatorL2Command(elevatorSubsystem);
        } else {
            // Level 0 or 1 both go to zero position
            levelCommand = new ElevatorZeroCommand(elevatorSubsystem);
        }
        
        levelCommand.schedule();
    }

    /**
     * Called repeatedly while the command is scheduled.
     * No continuous action needed - the level command handles movement.
     */
    @Override
    public void execute() {
    }

    /**
     * Called once when the command ends or is interrupted.
     * No cleanup needed.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
    }

    /**
     * Returns whether the command has finished.
     * 
     * @return true - finishes immediately after scheduling the level command
     */
    @Override
    public boolean isFinished() {
        return true;
    }
}
