package frc.robot.commands.ElevatorCommands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants.ElevatorConstants;
import frc.robot.subsystems.ElevatorSubsystem;

/**
 * Command to move the elevator to Level 1 position.
 * 
 * <p>This command moves the elevator to the lowest scoring position (Level 1).
 * It uses PID control to smoothly reach and hold the target position.
 * 
 * <p><b>For Beginners:</b> Level 1 is the lowest height for scoring game pieces.
 * The elevator will automatically move to this height and stay there.
 * 
 * @author FRC Team 9569
 */
public class ElevatorL1Command extends Command {
    private final ElevatorSubsystem elevatorSubsystem;

    /**
     * Creates a new ElevatorL1Command.
     * 
     * @param elevatorSubsystem The elevator subsystem to control
     */
    public ElevatorL1Command(ElevatorSubsystem elevatorSubsystem) {
        this.elevatorSubsystem = elevatorSubsystem;
        addRequirements(elevatorSubsystem);
    }
    
    /**
     * Called once when the command is initially scheduled.
     * Sets the elevator level tracker to 0 (Level 1).
     */
    @Override
    public void initialize() {
        elevatorSubsystem.setLevel(0);
    }

    /**
     * Called repeatedly while the command is scheduled.
     * Continuously moves the elevator toward the Level 1 position.
     */
    @Override
    public void execute() {
        elevatorSubsystem.moveToPosition(ElevatorConstants.LEVEL_1_POSITION);
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * Stops the elevator motors.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        elevatorSubsystem.stop();
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * @return false - command runs until interrupted
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}
