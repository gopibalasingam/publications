package frc.robot;

import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;

import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.button.CommandPS5Controller;
import edu.wpi.first.wpilibj2.command.button.CommandXboxController;
import frc.robot.Constants.OperatorConstants;
import frc.robot.commands.FlashBang;
import frc.robot.commands.AlgaeCommands.AlgaeEject;
import frc.robot.commands.AlgaeCommands.AlgaeIntake;
import frc.robot.commands.AlgaeCommands.AlgaePivotDown;
import frc.robot.commands.AlgaeCommands.AlgaePivotMiddle;
import frc.robot.commands.AlgaeCommands.AlgaePivotUp;
import frc.robot.commands.AlgaeCommands.AlgaePivotUpper;
import frc.robot.commands.CoralCommands.CoralEjectCommand;
import frc.robot.commands.CoralCommands.CoralForceDiffEjectCommand;
import frc.robot.commands.CoralCommands.CoralIntakeCommand;
import frc.robot.commands.ElevatorCommands.ElevatorCycle;
import frc.robot.commands.ElevatorCommands.ElevatorZeroCommand;
import frc.robot.subsystems.AlgaeEndeffactorSubsystem;
import frc.robot.subsystems.CoralEndeffactorSubsystem;
import frc.robot.subsystems.ElevatorSubsystem;
import frc.robot.subsystems.LEDSubsystem;
import frc.robot.subsystems.SwerveSubsystem;
import frc.robot.subsystems.Vision;
import swervelib.SwerveInputStream;

/**
 * Container for robot subsystems, controllers, and command bindings.
 * 
 * <p>This class organizes all robot components and defines how operator inputs
 * trigger robot actions. Think of it as the "wiring diagram" for the robot.
 * 
 * <p><b>Beginner Note:</b> Command-based programming separates robot hardware (subsystems)
 * from robot actions (commands). This class connects them together.
 * 
 * <p><b>Design Pattern:</b> Follows the Dependency Injection pattern - all subsystems
 * are created here and passed to commands that need them.
 * 
 * <p><b>Organization:</b>
 * <ul>
 *   <li>Subsystems - Hardware components (drive, elevator, intakes)</li>
 *   <li>Controllers - Driver and operator input devices</li>
 *   <li>Auto Chooser - Autonomous routine selector</li>
 *   <li>Command Bindings - Maps buttons to commands</li>
 * </ul>
 * 
 * @author FRC Team 9569
 */
public class RobotContainer {
    
    // ========== Subsystems ==========
    /** Swerve drive subsystem for robot movement. */
    private final SwerveSubsystem swerveSubsystem;
    
    /** Elevator subsystem for vertical positioning. */
    private final ElevatorSubsystem elevatorSubsystem;
    
    /** Coral intake subsystem. */
    private final CoralEndeffactorSubsystem coralSubsystem;
    
    /** Algae intake subsystem. */
    private final AlgaeEndeffactorSubsystem algaeSubsystem;
    
    /** LED subsystem for visual feedback. */
    private final LEDSubsystem ledSubsystem;
    
    /** Vision subsystem for AprilTag detection. */
    private final Vision visionSubsystem;

    // ========== Controllers ==========
    /** Driver controller (PS5) for driving the robot. */
    private final CommandPS5Controller driverController;
    
    /** Operator controller (Xbox) for manipulator controls. */
    private final CommandXboxController operatorController;

    // ========== Autonomous ==========
    /** Autonomous routine chooser displayed on dashboard. */
    private final SendableChooser<Command> autoChooser;

    /**
     * Creates a new RobotContainer.
     * 
     * <p>This constructor:
     * <ul>
     *   <li>Initializes all subsystems</li>
     *   <li>Creates controller instances</li>
     *   <li>Registers autonomous commands</li>
     *   <li>Configures button bindings</li>
     *   <li>Sets default commands</li>
     * </ul>
     */
    public RobotContainer() {
        // Initialize subsystems
        swerveSubsystem = new SwerveSubsystem();
        elevatorSubsystem = new ElevatorSubsystem();
        coralSubsystem = new CoralEndeffactorSubsystem();
        algaeSubsystem = new AlgaeEndeffactorSubsystem();
        ledSubsystem = new LEDSubsystem();
        visionSubsystem = new Vision();
        
        // Initialize controllers
        driverController = new CommandPS5Controller(OperatorConstants.DRIVER_CONTROLLER_PORT);
        operatorController = new CommandXboxController(OperatorConstants.OPERATOR_CONTROLLER_PORT);
        
        // Register autonomous commands and build chooser
        registerAutonomousCommands();
        autoChooser = AutoBuilder.buildAutoChooser();
        SmartDashboard.putData("Auto Chooser", autoChooser);
        
        // Configure button bindings
        configureBindings();
        
        // Set default drive command
        configureDriveMode();
    }

    /**
     * Registers named commands for use in PathPlanner autonomous routines.
     * 
     * <p><b>Beginner Note:</b> PathPlanner lets you create autonomous paths
     * with named commands at specific points. These commands are defined here.
     */
    private void registerAutonomousCommands() {
        NamedCommands.registerCommand("EC", new CoralForceDiffEjectCommand(coralSubsystem, elevatorSubsystem, ledSubsystem));
        NamedCommands.registerCommand("IC", new CoralIntakeCommand(coralSubsystem, ledSubsystem));
        NamedCommands.registerCommand("L0", new ElevatorZeroCommand(elevatorSubsystem));
    }

    /**
     * Configures drive mode based on whether robot is in simulation or real.
     * 
     * <p><b>Simulation:</b> Uses direct angle control (for keyboard input)
     * <br><b>Real Robot:</b> Uses angular velocity control (for joystick input)
     */
    private void configureDriveMode() {
        SwerveInputStream driveAngularVelocity = SwerveInputStream.of(
            swerveSubsystem.getSwerveDrive(),
            () -> -driverController.getLeftY(),
            () -> -driverController.getLeftX()
        )
        .withControllerRotationAxis(driverController::getRightX)
        .deadband(OperatorConstants.DEADBAND)
        .scaleTranslation(1.0)
        .allianceRelativeControl(true);

        Command driveFieldOrientedAngularVelocity = swerveSubsystem.driveFieldOriented(driveAngularVelocity);
        
        if (RobotBase.isSimulation()) {
            // Simulation mode - keyboard/mouse control
            SwerveInputStream driveDirectAngle = driveAngularVelocity.copy()
                .withControllerHeadingAxis(driverController::getRightX, driverController::getRightY)
                .headingWhile(true);
            Command driveFieldOrientedDirectAngle = swerveSubsystem.driveFieldOriented(driveDirectAngle);
            swerveSubsystem.setDefaultCommand(driveFieldOrientedDirectAngle);
        } else {
            // Real robot - joystick control
            swerveSubsystem.setDefaultCommand(driveFieldOrientedAngularVelocity);
        }
    }

    /**
     * Configures all button bindings for driver and operator controllers.
     * 
     * <p><b>Organization:</b>
     * <ul>
     *   <li>Driver Controls - Driving, gyro reset, auto-align</li>
     *   <li>Operator Controls - All manipulator functions</li>
     * </ul>
     */
    private void configureBindings() {
        configureDriverBindings();
        configureOperatorBindings();
    }

    /**
     * Configures driver controller bindings (PS5 controller).
     * 
     * <p><b>Driver Controls (PS5):</b>
     * <ul>
     *   <li>Left Stick - Translate robot</li>
     *   <li>Right Stick - Rotate robot</li>
     *   <li>R1 - Cycle elevator up one level</li>
     *   <li>L1 - Cycle elevator down one level</li>
     *   <li>D-Pad Up - Zero gyro (reset field orientation)</li>
     *   <li>D-Pad Down - Flash LEDs (visual effect)</li>
     * </ul>
     */
    private void configureDriverBindings() {
        // Elevator level cycling
        driverController.R1().onTrue(new ElevatorCycle(elevatorSubsystem, 1));
        driverController.L1().onTrue(new ElevatorCycle(elevatorSubsystem, -1));
        
        // Gyro reset
        driverController.povUp().onTrue(Commands.runOnce(() -> swerveSubsystem.zeroGyro()));
        
        // LED flash effect
        driverController.povDown().whileTrue(new FlashBang(ledSubsystem));
    }

    /**
     * Configures operator controller bindings (Xbox controller).
     * 
     * <p><b>Operator Controls (Xbox):</b>
     * <ul>
     *   <li>Left Bumper - Intake coral</li>
     *   <li>Right Bumper - Eject coral</li>
     *   <li>Y Button - Algae pivot up</li>
     *   <li>X Button - Algae pivot middle</li>
     *   <li>A Button - Algae pivot down</li>
     *   <li>B Button - Algae pivot upper</li>
     *   <li>Right Trigger - Algae intake</li>
     *   <li>Left Trigger - Algae eject</li>
     *   <li>D-Pad Left - Coral differential right</li>
     *   <li>D-Pad Right - Coral differential left</li>
     * </ul>
     */
    private void configureOperatorBindings() {
        // Coral intake controls
        operatorController.leftBumper().onTrue(new CoralIntakeCommand(coralSubsystem, ledSubsystem));
        operatorController.rightBumper().onTrue(new CoralEjectCommand(coralSubsystem, elevatorSubsystem, ledSubsystem));
        
        // Algae pivot position controls
        operatorController.y().onTrue(new AlgaePivotUp(algaeSubsystem));
        operatorController.x().onTrue(new AlgaePivotMiddle(algaeSubsystem));
        operatorController.a().onTrue(new AlgaePivotDown(algaeSubsystem));
        operatorController.b().onTrue(new AlgaePivotUpper(algaeSubsystem));
        
        // Algae intake/eject controls
        operatorController.rightTrigger().whileTrue(new AlgaeIntake(algaeSubsystem));
        operatorController.leftTrigger().whileTrue(new AlgaeEject(algaeSubsystem));
        
        // Coral differential speed controls
        operatorController.povLeft().onTrue(Commands.runOnce(() -> coralSubsystem.setDifferentialRight()));
        operatorController.povRight().onTrue(Commands.runOnce(() -> coralSubsystem.setDifferentialLeft()));
    }

    /**
     * Returns the autonomous command selected on the dashboard.
     * 
     * <p><b>Beginner Note:</b> This method is called by Robot.java when
     * autonomous mode starts. The dashboard chooser lets you select which
     * autonomous routine to run.
     * 
     * @return The selected autonomous command
     */
    public Command getAutonomousCommand() {
        return autoChooser.getSelected();
    }
}
