package frc.robot.commands.ElevatorCommands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants.ElevatorConstants;
import frc.robot.subsystems.ElevatorSubsystem;

/**
 * Command to move the elevator to the zero (retracted) position.
 * 
 * <p>This command moves the elevator to its fully retracted position.
 * This is the safe position for driving and maneuvering the robot.
 * 
 * <p><b>For Beginners:</b> The zero position is the lowest point where
 * the elevator is completely retracted. This is used when driving around
 * or when the elevator isn't needed.
 * 
 * @author FRC Team 9569
 */
public class ElevatorZeroCommand extends Command {
    private final ElevatorSubsystem elevatorSubsystem;

    /**
     * Creates a new ElevatorZeroCommand.
     * 
     * @param elevatorSubsystem The elevator subsystem to control
     */
    public ElevatorZeroCommand(ElevatorSubsystem elevatorSubsystem) {
        this.elevatorSubsystem = elevatorSubsystem;
        addRequirements(elevatorSubsystem);
    }
    
    /**
     * Called once when the command is initially scheduled.
     * Sets the elevator level tracker to 1 (zero/retracted).
     */
    @Override
    public void initialize() {
        elevatorSubsystem.setLevel(1);
    }

    /**
     * Called repeatedly while the command is scheduled.
     * Continuously moves the elevator toward the zero position.
     */
    @Override
    public void execute() {
        elevatorSubsystem.moveToPosition(ElevatorConstants.ZERO_POSITION);
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * Stops the elevator motors.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        elevatorSubsystem.stop();
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * @return false - command runs until interrupted
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}
