package frc.robot.commands.AlgaeCommands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants.AlgaeConstants;
import frc.robot.subsystems.AlgaeEndeffactorSubsystem;

/**
 * Command to intake algae game pieces.
 * 
 * <p>This command runs the algae intake motors to pull algae into the robot.
 * The command continues until manually stopped by releasing the button.
 * 
 * <p><b>For Beginners:</b> This command makes the algae intake spin inward
 * to collect algae from the field. It runs continuously while you hold the button.
 * 
 * <p><b>Design Pattern:</b> This follows the Command pattern from WPILib's
 * command-based framework. Commands have a lifecycle: initialize → execute (repeats) → end.
 * 
 * @author FRC Team 9569
 */
public class AlgaeIntake extends Command {
    private final AlgaeEndeffactorSubsystem algaeSubsystem;
    
    /**
     * Creates a new AlgaeIntake command.
     * 
     * @param algaeSubsystem The algae end effector subsystem to control
     */
    public AlgaeIntake(AlgaeEndeffactorSubsystem algaeSubsystem) {
        this.algaeSubsystem = algaeSubsystem;
        addRequirements(algaeSubsystem);
    }

    /**
     * Called once when the command is initially scheduled.
     * Starts the algae intake motors.
     */
    @Override
    public void initialize() {
        algaeSubsystem.setIntakeSpeed(AlgaeConstants.INTAKE_VOLTAGE);
    }

    /**
     * Called repeatedly while the command is scheduled.
     * Continues running the intake motors.
     */
    @Override
    public void execute() {
        algaeSubsystem.setIntakeSpeed(AlgaeConstants.INTAKE_VOLTAGE);
    }

    /**
     * Called once when the command ends or is interrupted.
     * Stops the intake motors.
     * 
     * @param interrupted true if the command was interrupted, false if it ended normally
     */
    @Override
    public void end(boolean interrupted) {
        algaeSubsystem.stopIntake();
    }

    /**
     * Returns whether the command has finished.
     * 
     * <p><b>For Beginners:</b> This returns false because we want the intake
     * to keep running until the operator releases the button.
     * 
     * @return false - command runs until interrupted
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}