package frc.robot.commands.AlgaeCommands;

import edu.wpi.first.wpilibj2.command.SequentialCommandGroup;
import frc.robot.subsystems.AlgaeEndeffactorSubsystem;

/**
 * Sequential command group for algae intake sequence.
 * 
 * <p>This command runs a sequence of commands to intake algae game pieces.
 * Currently it just runs the algae intake command continuously.
 * 
 * <p><b>For Beginners:</b> This is a "command group" - it runs multiple
 * commands in order. Right now it only runs the intake, but you could add
 * more steps like positioning the pivot first.
 * 
 * <p><b>Example Usage:</b> To add a timeout or additional steps:
 * <pre>
 * addCommands(
 *     new AlgaePivotDown(algaeEndeffactorSubsystem).withTimeout(0.5),
 *     new AlgaeIntake(algaeEndeffactorSubsystem).withTimeout(2.0)
 * );
 * </pre>
 * 
 * @author FRC Team 9569
 */
public class AlgaeSeqIntake extends SequentialCommandGroup {
    /**
     * Creates a new AlgaeSeqIntake command group.
     * 
     * @param algaeEndeffactorSubsystem The algae subsystem used by the commands
     */
    public AlgaeSeqIntake(AlgaeEndeffactorSubsystem algaeEndeffactorSubsystem) {
        addCommands(
            new AlgaeIntake(algaeEndeffactorSubsystem)
        );
    }
}
