package frc.robot.commands;

import edu.wpi.first.wpilibj.util.Color;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.LEDSubsystem;

/**
 * Command that creates a fast white blinking LED effect.
 * 
 * <p>This command rapidly blinks the LEDs white to create a "flashbang" effect.
 * When the command ends, it returns to a scrolling rainbow pattern.
 * 
 * <p><b>For Beginners:</b> This is a fun LED effect that can be triggered
 * by a button. It's useful for celebrations or getting attention!
 * 
 * <p><b>Note:</b> This command can run while the robot is disabled,
 * making it useful for testing or demonstrations.
 * 
 * @author FRC Team 9569
 */
public class FlashBang extends Command {
    private final LEDSubsystem ledSubsystem;
    
    /**
     * Allows this command to run even when the robot is disabled.
     * 
     * @return true - this command can run while disabled
     */
    @Override
    public boolean runsWhenDisabled() {
        return true;
    }

    /**
     * Creates a new FlashBang command.
     * 
     * @param ledSubsystem The LED subsystem to control
     */
    public FlashBang(LEDSubsystem ledSubsystem) {
        this.ledSubsystem = ledSubsystem;
    }
    
    /**
     * Called once when the command is initially scheduled.
     * Starts the fast white blinking pattern.
     */
    @Override
    public void initialize() {
        ledSubsystem.setBlink(Color.kWhite, 0.05);
    }

    /**
     * Called repeatedly while the command is scheduled.
     * No action needed - the blink pattern continues automatically.
     */
    @Override
    public void execute() {
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * Returns LEDs to the default scrolling rainbow pattern.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        ledSubsystem.setRainbowScrolling();
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * @return false - command runs until button is released
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}

