package frc.robot;

import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.auto.NamedCommands;

import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.wpilibj.RobotBase;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.button.CommandPS5Controller;
import edu.wpi.first.wpilibj2.command.button.CommandXboxController;
import frc.robot.Constants.OperatorConstants;
import frc.robot.commands.FlashBang;
import frc.robot.commands.AlgaeCommands.AlgaeEject;
import frc.robot.commands.AlgaeCommands.AlgaeIntake;
import frc.robot.commands.AlgaeCommands.AlgaePivotDown;
import frc.robot.commands.AlgaeCommands.AlgaePivotMiddle;
import frc.robot.commands.AlgaeCommands.AlgaePivotUp;
import frc.robot.commands.AlgaeCommands.AlgaePivotUpper;
import frc.robot.commands.CoralCommands.CoralEjectCommand;
import frc.robot.commands.CoralCommands.CoralForceDiffEjectCommand;
import frc.robot.commands.CoralCommands.CoralIntakeCommand;
import frc.robot.commands.ElevatorCommands.ElevatorCycle;
import frc.robot.commands.ElevatorCommands.ElevatorL1Command;
import frc.robot.commands.ElevatorCommands.ElevatorL2Command;
import frc.robot.commands.ElevatorCommands.ElevatorL3Command;
import frc.robot.commands.ElevatorCommands.ElevatorZeroCommand;
import frc.robot.subsystems.AlgaeEndeffactorSubsystem;
import frc.robot.subsystems.CoralEndeffactorSubsystem;
import frc.robot.subsystems.ElevatorSubsystem;
import frc.robot.subsystems.LEDSubsystem;
import frc.robot.subsystems.SwerveSubsystem;
import frc.robot.subsystems.Vision;
import swervelib.SwerveInputStream;

/**
 * Container for robot subsystems, controllers, and command bindings.
 * 
 * <p>This class organizes all robot components and defines how operator inputs
 * trigger robot actions. Think of it as the "wiring diagram" for the robot.
 * 
 * <p><b>Beginner Note:</b> Command-based programming separates robot hardware (subsystems)
 * from robot actions (commands). This class connects them together by:
 * <ul>
 *   <li>Creating all subsystems (mechanical components)</li>
 *   <li>Creating controllers for human operators</li>
 *   <li>Binding buttons to commands (actions)</li>
 * </ul>
 * 
 * <p><b>Design Pattern:</b> Follows the Dependency Injection pattern - all subsystems
 * are created here and passed to commands that need them.
 */
public class RobotContainer {
    
    private final SwerveSubsystem swerveSubsystem;
    private final ElevatorSubsystem elevatorSubsystem;
    private final CoralEndeffactorSubsystem coralSubsystem;
    private final AlgaeEndeffactorSubsystem algaeSubsystem;
    private final LEDSubsystem ledSubsystem;
    private final Vision visionSubsystem;

    private final CommandPS5Controller driverController;
    private final CommandXboxController operatorController;
    
    private final SendableChooser<Command> autoChooser;

    /**
     * Creates a new RobotContainer.
     * 
     * <p>This constructor initializes all subsystems, controllers, and command bindings.
     * It's called once when the robot starts up.
     */
    public RobotContainer() {
        swerveSubsystem = new SwerveSubsystem();
        elevatorSubsystem = new ElevatorSubsystem();
        coralSubsystem = new CoralEndeffactorSubsystem();
        algaeSubsystem = new AlgaeEndeffactorSubsystem();
        ledSubsystem = new LEDSubsystem();
        visionSubsystem = new Vision();

        driverController = new CommandPS5Controller(OperatorConstants.DRIVER_CONTROLLER_PORT);
        operatorController = new CommandXboxController(OperatorConstants.OPERATOR_CONTROLLER_PORT);

        configureAutonomousCommands();
        configureDefaultCommands();
        configureButtonBindings();
        configureDashboard();
    }

    /**
     * Registers named commands for use in autonomous paths.
     * 
     * <p><b>Beginner Note:</b> PathPlanner autonomous paths can call these commands by name.
     * This allows you to draw a path and add actions like "intake coral" at specific points.
     */
    private void configureAutonomousCommands() {
        NamedCommands.registerCommand("EC", new CoralForceDiffEjectCommand(coralSubsystem, elevatorSubsystem, ledSubsystem));
        NamedCommands.registerCommand("IC", new CoralIntakeCommand(coralSubsystem, ledSubsystem));
        NamedCommands.registerCommand("L0", new ElevatorZeroCommand(elevatorSubsystem));
        NamedCommands.registerCommand("L1", new ElevatorL1Command(elevatorSubsystem));
        NamedCommands.registerCommand("L2", new ElevatorL2Command(elevatorSubsystem));
        NamedCommands.registerCommand("L3", new ElevatorL3Command(elevatorSubsystem));
        
        autoChooser = AutoBuilder.buildAutoChooser();
    }

    /**
     * Sets default commands that run when no other commands are using a subsystem.
     * 
     * <p><b>Beginner Note:</b> The swerve drive's default command reads joystick inputs.
     * This means the driver can always control movement unless another command takes over.
     */
    private void configureDefaultCommands() {
        SwerveInputStream driveInput;
        
        if (RobotBase.isSimulation()) {
            driveInput = createKeyboardDriveInput();
        } else {
            driveInput = createJoystickDriveInput();
        }
        
        swerveSubsystem.setDefaultCommand(swerveSubsystem.driveFieldOriented(driveInput));
    }

    /**
     * Creates drive input configuration for joystick control.
     * 
     * @return Configured SwerveInputStream for joystick driving
     */
    private SwerveInputStream createJoystickDriveInput() {
        return SwerveInputStream.of(
            swerveSubsystem.getSwerveDrive(),
            () -> -driverController.getLeftY(),
            () -> -driverController.getLeftX()
        )
        .withControllerRotationAxis(driverController::getRightX)
        .deadband(OperatorConstants.JOYSTICK_DEADBAND)
        .scaleTranslation(1.0)
        .allianceRelativeControl(true);
    }

    /**
     * Creates drive input configuration for keyboard control (simulation).
     * 
     * @return Configured SwerveInputStream for keyboard driving
     */
    private SwerveInputStream createKeyboardDriveInput() {
        SwerveInputStream baseInput = SwerveInputStream.of(
            swerveSubsystem.getSwerveDrive(),
            () -> -driverController.getLeftY(),
            () -> -driverController.getLeftX()
        )
        .withControllerRotationAxis(() -> driverController.getRawAxis(2))
        .deadband(OperatorConstants.JOYSTICK_DEADBAND)
        .scaleTranslation(0.8)
        .allianceRelativeControl(true);
        
        return baseInput.copy()
            .withControllerHeadingAxis(
                () -> Math.sin(driverController.getRawAxis(2) * Math.PI) * (Math.PI * 2),
                () -> Math.cos(driverController.getRawAxis(2) * Math.PI) * (Math.PI * 2)
            )
            .headingWhile(true)
            .translationHeadingOffset(true)
            .translationHeadingOffset(Rotation2d.fromDegrees(0));
    }

    /**
     * Binds controller buttons to commands.
     * 
     * <p><b>Beginner Note:</b> This method maps physical buttons to robot actions.
     * For example, pressing the right bumper triggers coral ejection.
     * 
     * <p>Driver Controller (PS5):
     * <ul>
     *   <li>Left Stick: Drive translation</li>
     *   <li>Right Stick: Drive rotation</li>
     *   <li>R1: Cycle elevator up</li>
     *   <li>L1: Cycle elevator down</li>
     *   <li>POV Up: Reset gyro to zero</li>
     *   <li>POV Down: FlashBang LED effect</li>
     * </ul>
     * 
     * <p>Operator Controller (Xbox):
     * <ul>
     *   <li>Left Bumper: Intake coral</li>
     *   <li>Right Bumper: Eject coral</li>
     *   <li>Y Button: Algae pivot up</li>
     *   <li>X Button: Algae pivot middle</li>
     *   <li>A Button: Algae pivot down</li>
     *   <li>B Button: Algae pivot upper</li>
     *   <li>Right Trigger: Algae intake</li>
     *   <li>Left Trigger: Algae eject</li>
     *   <li>POV Left: Coral differential right</li>
     *   <li>POV Right: Coral differential left</li>
     * </ul>
     */
    private void configureButtonBindings() {
        driverController.R1().onTrue(new ElevatorCycle(elevatorSubsystem, 1));
        driverController.L1().onTrue(new ElevatorCycle(elevatorSubsystem, -1));
        driverController.povUp().onTrue(Commands.runOnce(swerveSubsystem::zeroGyro));
        driverController.povDown().whileTrue(new FlashBang(ledSubsystem));

        operatorController.leftBumper().onTrue(new CoralIntakeCommand(coralSubsystem, ledSubsystem));
        operatorController.rightBumper().onTrue(new CoralEjectCommand(coralSubsystem, elevatorSubsystem, ledSubsystem));

        operatorController.y().onTrue(new AlgaePivotUp(algaeSubsystem));
        operatorController.x().onTrue(new AlgaePivotMiddle(algaeSubsystem));
        operatorController.a().onTrue(new AlgaePivotDown(algaeSubsystem));
        operatorController.b().onTrue(new AlgaePivotUpper(algaeSubsystem));

        operatorController.rightTrigger().whileTrue(new AlgaeIntake(algaeSubsystem));
        operatorController.leftTrigger().whileTrue(new AlgaeEject(algaeSubsystem));

        operatorController.povLeft().onTrue(Commands.runOnce(coralSubsystem::setDifferentialRight));
        operatorController.povRight().onTrue(Commands.runOnce(coralSubsystem::setDifferentialLeft));
    }

    /**
     * Sends data to the SmartDashboard for debugging and monitoring.
     */
    private void configureDashboard() {
        SmartDashboard.putData("Auto Chooser", autoChooser);
    }

    /**
     * Gets the autonomous command to run.
     * 
     * <p><b>Beginner Note:</b> This is called by Robot.java when autonomous starts.
     * The command comes from the autonomous chooser on the dashboard.
     * 
     * @return The selected autonomous command
     */
    public Command getAutonomousCommand() {
        return autoChooser.getSelected();
    }
}
