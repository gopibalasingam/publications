package frc.robot.commands.CoralCommands;

import edu.wpi.first.wpilibj.util.Color;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants.CoralConstants;
import frc.robot.subsystems.CoralEndeffactorSubsystem;
import frc.robot.subsystems.LEDSubsystem;

/**
 * Command to intake coral game pieces.
 * 
 * <p>This command runs the coral intake motors at different speeds depending
 * on whether a game piece is detected. It uses beam break sensors to detect
 * when a coral enters the intake, then slows down to securely grab it.
 * 
 * <p>The command finishes when the coral is fully inside (detected by inner sensor).
 * LED feedback shows yellow during intake and green when complete.
 * 
 * <p><b>For Beginners:</b> This command automatically adjusts intake speed:
 * <ul>
 * <li>Runs fast (12V) when no coral detected</li>
 * <li>Slows down (4V) when coral enters to avoid damage</li>
 * <li>Stops when coral is fully secured inside</li>
 * </ul>
 * 
 * @author FRC Team 9569
 */
public class CoralIntakeCommand extends Command {
    private final CoralEndeffactorSubsystem coralEndeffactorSubsystem;
    private final LEDSubsystem ledSubsystem;

    /**
     * Creates a new CoralIntakeCommand.
     * 
     * @param coralEndeffactorSubsystem The coral subsystem to control
     * @param ledSubsystem The LED subsystem for visual feedback
     */
    public CoralIntakeCommand(CoralEndeffactorSubsystem coralEndeffactorSubsystem, LEDSubsystem ledSubsystem) {
        this.coralEndeffactorSubsystem = coralEndeffactorSubsystem;
        this.ledSubsystem = ledSubsystem;
        addRequirements(coralEndeffactorSubsystem);
    }
    
    /**
     * Called once when the command is initially scheduled.
     * Sets LEDs to yellow to indicate intake is active.
     */
    @Override
    public void initialize() {
        ledSubsystem.setSolidColor(Color.kYellow);
    }

    /**
     * Called repeatedly while the command is scheduled.
     * 
     * <p>Adjusts intake speed based on sensor detection:
     * <ul>
     * <li>If outer sensor NOT blocked: Run at slow speed (coral entering)</li>
     * <li>If outer sensor IS blocked: Run at full speed (no coral yet)</li>
     * </ul>
     */
    @Override
    public void execute() {
        if (!coralEndeffactorSubsystem.isOuterSensorBlocked()) {
            coralEndeffactorSubsystem.setVoltage(CoralConstants.SLOW_INTAKE_VOLTAGE);
        } else {
            coralEndeffactorSubsystem.setVoltage(CoralConstants.INTAKE_VOLTAGE);
        }
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * Stops the motors and sets LEDs to green (success).
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        coralEndeffactorSubsystem.stop();
        ledSubsystem.setSolidColor(Color.kGreen);
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * <p>Finishes when the inner sensor detects the coral is fully inside.
     * 
     * @return true when coral is fully intaked
     */
    @Override
    public boolean isFinished() {
        return coralEndeffactorSubsystem.isObjectIn();
    }
}
}
