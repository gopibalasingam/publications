package frc.robot.subsystems;

import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkLowLevel.MotorType;
import com.revrobotics.spark.SparkMax;

import edu.wpi.first.wpilibj.DigitalInput;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants.CoralConstants;
import frc.robot.Constants.HardwareMap;

/**
 * Subsystem for controlling the coral intake mechanism.
 * 
 * <p>This subsystem manages two motors that work together to intake and eject coral game pieces.
 * It includes beam break sensors to detect when a coral is fully inside the mechanism.
 * 
 * <p><b>Beginner Note:</b> This intake has two sensors (beam breaks) that detect objects:
 * <ul>
 *   <li>Inner sensor: Detects when coral first enters</li>
 *   <li>Outer sensor: Detects when coral is fully captured</li>
 * </ul>
 * 
 * <p><b>Design Pattern:</b> This class uses the State pattern to track differential drive ratios.
 */
public class CoralEndeffactorSubsystem extends SubsystemBase {

    private final SparkMax leftMotor;
    private final SparkMax rightMotor;
    private final RelativeEncoder leftEncoder;
    private final RelativeEncoder rightEncoder;
    private final DigitalInput innerBeamBreak;
    private final DigitalInput outerBeamBreak;
    
    private double leftSpeedRatio;
    private double rightSpeedRatio;

    /**
     * Creates a new CoralEndeffactorSubsystem.
     * \n     * <p>Initializes motors and sensors. The right motor is inverted
     * so both motors spin the same direction for intake.
     */
    public CoralEndeffactorSubsystem() {
        leftMotor = new SparkMax(HardwareMap.CORAL_MOTOR_LEFT_ID, MotorType.kBrushless);
        rightMotor = new SparkMax(HardwareMap.CORAL_MOTOR_RIGHT_ID, MotorType.kBrushless);
        
        leftEncoder = leftMotor.getEncoder();
        rightEncoder = rightMotor.getEncoder();
        
        innerBeamBreak = new DigitalInput(HardwareMap.BEAM_BREAK_INNER_PORT);
        outerBeamBreak = new DigitalInput(HardwareMap.BEAM_BREAK_OUTER_PORT);
        
        configureMotors();
        initializeDifferentialRatios();
    }
    
    /**
     * Configures motor settings.
     * Sets the right motor to inverted so both motors spin the same direction.
     */
    private void configureMotors() {
        rightMotor.setInverted(true);
    }
    
    /**
     * Initializes differential speed ratios to equal speed.
     * Called during subsystem construction.
     */
    private void initializeDifferentialRatios() {
        leftSpeedRatio = CoralConstants.DIFF_FULL_SPEED;
        rightSpeedRatio = CoralConstants.DIFF_FULL_SPEED;
    }
    
    /**
     * Resets differential speed ratios to equal speed for both motors.
     */
    public void resetDifferentialRatios() {
        initializeDifferentialRatios();
    }

    /**
     * Sets both motors to the same voltage.
     * 
     * <p><b>Beginner Note:</b> Positive voltage intakes, negative voltage ejects.
     * 
     * @param voltage The voltage to apply to both motors (-12.0 to +12.0 volts)
     */
    public void setVoltage(double voltage) {
        leftMotor.setVoltage(voltage);
        rightMotor.setVoltage(voltage);
    }

    /**
     * Sets motors to different voltages using differential ratios.
     * 
     * <p>This allows the intake to turn the coral slightly while intaking.
     * Used for centering the game piece.
     * 
     * @param voltage The base voltage to apply
     */
    public void setVoltageDifferential(double voltage) {
        leftMotor.setVoltage(leftSpeedRatio * voltage);
        rightMotor.setVoltage(rightSpeedRatio * voltage);
    }

    /**
     * Stops both motors immediately.
     */
    public void stop() {
        leftMotor.setVoltage(0);
        rightMotor.setVoltage(0);
    }

    /**
     * Gets the left motor encoder position.
     * 
     * @return The encoder position in rotations
     */
    public double getLeftEncoderPosition() {
        return leftEncoder.getPosition();
    }

    /**
     * Configures differential to favor the right motor.
     * This causes the intake to turn the coral counterclockwise.
     */
    public void setDifferentialRight() {
        leftSpeedRatio = CoralConstants.DIFF_REDUCED_SPEED;
        rightSpeedRatio = CoralConstants.DIFF_FULL_SPEED;
    }

    /**
     * Configures differential to favor the left motor.
     * This causes the intake to turn the coral clockwise.
     */
    public void setDifferentialLeft() {
        leftSpeedRatio = CoralConstants.DIFF_FULL_SPEED;
        rightSpeedRatio = CoralConstants.DIFF_REDUCED_SPEED;
    }

    /**
     * Checks if the outer beam break sensor is blocked.
     * 
     * <p><b>Beginner Note:</b> Beam breaks work backwards - they return false when blocked.
     * 
     * @return true if the beam is blocked (coral detected), false otherwise
     */
    public boolean isOuterSensorBlocked() {
        return !outerBeamBreak.get();
    }

    /**
     * Checks if the inner beam break sensor is blocked.
     * 
     * @return true if the beam is blocked (coral detected), false otherwise
     */
    public boolean isInnerSensorBlocked() {
        return !innerBeamBreak.get();
    }

    /**
     * Checks if a coral is fully captured in the intake.
     * 
     * <p>A coral is considered captured when:
     * <ul>
     *   <li>The outer sensor is NOT blocked (coral passed through)</li>
     *   <li>The inner sensor IS blocked (coral is inside)</li>
     * </ul>
     * \n     * @return true if coral is fully captured, false otherwise
     */
    public boolean hasCoralCaptured() {
        return !isOuterSensorBlocked() && isInnerSensorBlocked();
    }
    
    /**
     * Alias for hasCoralCaptured() - checks if object is fully inside.
     * Kept for compatibility with existing commands.
     * 
     * @return true if coral is fully captured, false otherwise
     */
    public boolean isObjectIn() {
        return hasCoralCaptured();
    }

    /**
     * Periodic method called every 20ms by the scheduler.
     * Sends sensor data to the dashboard for debugging.
     */
    @Override
    public void periodic() {
        SmartDashboard.putBoolean("Coral/Outer Sensor Blocked", isOuterSensorBlocked());
        SmartDashboard.putBoolean("Coral/Inner Sensor Blocked", isInnerSensorBlocked());
        SmartDashboard.putBoolean("Coral/Has Captured", hasCoralCaptured());
    }
}
