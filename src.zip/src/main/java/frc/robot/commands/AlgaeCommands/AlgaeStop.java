package frc.robot.commands.AlgaeCommands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.AlgaeEndeffactorSubsystem;

/**
 * Command to stop the algae intake motors.
 * 
 * <p>This command stops all algae intake motor movement by setting
 * the speed to zero. It's used to manually stop the intake when needed.
 * 
 * <p><b>For Beginners:</b> This command simply turns off the intake
 * motors. It's useful for emergency stops or when you want to manually
 * control when the intake should stop.
 * 
 * @author FRC Team 9569
 */
public class AlgaeStop extends Command {
    private final AlgaeEndeffactorSubsystem algaeEndeffactorSubsystem;

    /**
     * Creates a new AlgaeStop command.
     * 
     * @param algaeEndeffactorSubsystem The algae subsystem to control
     */
    public AlgaeStop(AlgaeEndeffactorSubsystem algaeEndeffactorSubsystem) {
        this.algaeEndeffactorSubsystem = algaeEndeffactorSubsystem;
        addRequirements(algaeEndeffactorSubsystem);
    }
    
    /**
     * Called once when the command is initially scheduled.
     * Currently no initialization needed.
     */
    @Override
    public void initialize() {
    }

    /**
     * Called repeatedly while the command is scheduled.
     * Continuously sets the intake speed to zero.
     */
    @Override
    public void execute() {
        algaeEndeffactorSubsystem.stopIntake();
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * Ensures motors are stopped.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        algaeEndeffactorSubsystem.stopIntake();
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * @return false - command runs until interrupted
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}
