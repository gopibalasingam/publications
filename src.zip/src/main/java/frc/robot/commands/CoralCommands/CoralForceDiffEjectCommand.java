package frc.robot.commands.CoralCommands;

import edu.wpi.first.wpilibj.util.Color;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.CoralEndeffactorSubsystem;
import frc.robot.subsystems.ElevatorSubsystem;
import frc.robot.subsystems.LEDSubsystem;

/**
 * Command to force eject coral using differential speed.
 * 
 * <p>This command always uses differential eject at 5.5V regardless of
 * elevator level. The differential eject runs one motor faster than the other
 * to create a spinning effect that helps release stubborn game pieces.
 * 
 * <p>The command finishes when the inner beam break sensor detects the
 * coral has been ejected.
 * 
 * <p><b>For Beginners:</b> Use this command when normal ejection doesn't
 * work. The "differential" means the motors spin at different speeds,
 * creating a rotation that helps unstick game pieces.
 * 
 * @author FRC Team 9569
 */
public class CoralForceDiffEjectCommand extends Command {
    private final CoralEndeffactorSubsystem coralEndeffactorSubsystem;
    private final ElevatorSubsystem elevatorSubsystem;
    private final LEDSubsystem ledSubsystem;
    private int level;

    /**
     * Creates a new CoralForceDiffEjectCommand.
     * 
     * @param coralEndeffactorSubsystem The coral subsystem to control
     * @param elevatorSubsystem The elevator subsystem (recorded but not used)
     * @param ledSubsystem The LED subsystem for visual feedback
     */
    public CoralForceDiffEjectCommand(CoralEndeffactorSubsystem coralEndeffactorSubsystem,
                                     ElevatorSubsystem elevatorSubsystem,
                                     LEDSubsystem ledSubsystem) {
        this.coralEndeffactorSubsystem = coralEndeffactorSubsystem;
        this.elevatorSubsystem = elevatorSubsystem;
        this.ledSubsystem = ledSubsystem;
        addRequirements(coralEndeffactorSubsystem);
    }
    
    /**
     * Called once when the command is initially scheduled.
     * 
     * <p>Records the current elevator level and sets LEDs to red
     * to indicate ejection is active.
     */
    @Override
    public void initialize() {
        level = elevatorSubsystem.getLevel();
        ledSubsystem.setSolidColor(Color.kRed);
    }

    /**
     * Called repeatedly while the command is scheduled.
     * 
     * <p>Continuously runs differential eject at 5.5V to force
     * the coral out with spinning motion.
     */
    @Override
    public void execute() {
        coralEndeffactorSubsystem.setDifferentialVoltage(5.5);
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * 
     * <p>Stops the motors and returns LEDs to default color.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        coralEndeffactorSubsystem.stop();
        ledSubsystem.runDefaultColor();
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * <p>Finishes when the inner sensor no longer detects coral,
     * indicating the eject was successful.
     * 
     * @return true when inner sensor is clear (coral ejected)
     */
    @Override
    public boolean isFinished() {
        return coralEndeffactorSubsystem.isInnerSensorBlocked();
    }
}
