package frc.robot.commands.CoralCommands;

import edu.wpi.first.wpilibj.util.Color;
import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.CoralEndeffactorSubsystem;
import frc.robot.subsystems.ElevatorSubsystem;
import frc.robot.subsystems.LEDSubsystem;

/**
 * Command to eject coral game pieces.
 * 
 * <p>This command ejects coral by running the intake motors in reverse.
 * The eject voltage/method varies based on the elevator level:
 * <ul>
 * <li>Level 0 or 1 (low): Uses differential eject (3.8V) for better control</li>
 * <li>Level 2 or 3 (high): Uses normal eject (7.5V) for more power</li>
 * </ul>
 * 
 * <p>LED feedback shows red during ejection to indicate the action.
 * 
 * <p><b>For Beginners:</b> This command scores coral by pushing it out.
 * The eject method changes based on height - low heights need gentler
 * ejection, while high heights need more power.
 * 
 * @author FRC Team 9569
 */
public class CoralEjectCommand extends Command {
    private final CoralEndeffactorSubsystem coralEndeffactorSubsystem;
    private final ElevatorSubsystem elevatorSubsystem;
    private final LEDSubsystem ledSubsystem;
    private int level;

    /**
     * Creates a new CoralEjectCommand.
     * 
     * @param coralEndeffactorSubsystem The coral subsystem to control
     * @param elevatorSubsystem The elevator subsystem to check current level
     * @param ledSubsystem The LED subsystem for visual feedback
     */
    public CoralEjectCommand(CoralEndeffactorSubsystem coralEndeffactorSubsystem, 
                            ElevatorSubsystem elevatorSubsystem, 
                            LEDSubsystem ledSubsystem) {
        this.coralEndeffactorSubsystem = coralEndeffactorSubsystem;
        this.elevatorSubsystem = elevatorSubsystem;
        this.ledSubsystem = ledSubsystem;
        addRequirements(coralEndeffactorSubsystem);
    }
    
    /**
     * Called once when the command is initially scheduled.
     * 
     * <p>Records the current elevator level and sets LEDs to red
     * to indicate ejection is active.
     */
    @Override
    public void initialize() {
        level = elevatorSubsystem.getLevel();
        ledSubsystem.setSolidColor(Color.kRed);
    }

    /**
     * Called repeatedly while the command is scheduled.
     * 
     * <p>Ejects coral using different methods based on elevator height:
     * <ul>
     * <li>Low levels (0-1): Differential eject at 3.8V for precision</li>
     * <li>High levels (2-3): Standard eject at 7.5V for power</li>
     * </ul>
     */
    @Override
    public void execute() {
        if (level == 1 || level == 0) {
            coralEndeffactorSubsystem.setDifferentialVoltage(3.8);
        } else {
            coralEndeffactorSubsystem.setVoltage(7.5);
        }
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * 
     * <p>Stops the motors and returns LEDs to default color.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        coralEndeffactorSubsystem.stop();
        ledSubsystem.runDefaultColor();
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * @return false - command runs until interrupted (usually when button released)
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}
    @Override
    public boolean isFinished(){
        return coralEndeffactorSubsystem.beamBroken2();// Math.abs(900 - elevatorSubsystem.getPoint()) < 20; 
    }
}
