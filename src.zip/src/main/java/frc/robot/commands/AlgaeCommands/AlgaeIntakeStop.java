package frc.robot.commands.AlgaeCommands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.subsystems.AlgaeEndeffactorSubsystem;

/**
 * Command to stop the algae intake motors (instant command version).
 * 
 * <p>This command immediately stops the algae intake motors when scheduled.
 * Unlike AlgaeStop, this version doesn't require subsystem requirements,
 * making it useful in command groups where another command already has the requirement.
 * 
 * <p><b>For Beginners:</b> This is an alternative way to stop the intake.
 * It's designed to work well in command sequences where multiple commands
 * control the same subsystem.
 * 
 * @author FRC Team 9569
 */
public class AlgaeIntakeStop extends Command {
    private final AlgaeEndeffactorSubsystem algaeSubsystem;

    /**
     * Creates a new AlgaeIntakeStop command.
     * 
     * <p><b>Note:</b> This command does not require the subsystem,
     * allowing it to be used in command groups alongside other algae commands.
     * 
     * @param algaeSubsystem The algae subsystem to control
     */
    public AlgaeIntakeStop(AlgaeEndeffactorSubsystem algaeSubsystem) {
        this.algaeSubsystem = algaeSubsystem;
    }

    /**
     * Called once when the command is initially scheduled.
     * Immediately stops the intake motors.
     */
    @Override
    public void initialize() {
        algaeSubsystem.stopIntake();
    }

    /**
     * Called repeatedly while the command is scheduled.
     * No continuous action needed.
     */
    @Override
    public void execute() {
    }

    /**
     * Called once when the command ends or is interrupted.
     * Ensures motors remain stopped.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        algaeSubsystem.stopIntake();
    }

    /**
     * Returns whether the command has finished.
     * 
     * @return false - command runs until interrupted
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}