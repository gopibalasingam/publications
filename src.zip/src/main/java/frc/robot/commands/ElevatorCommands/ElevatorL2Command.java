package frc.robot.commands.ElevatorCommands;

import edu.wpi.first.wpilibj2.command.Command;
import frc.robot.Constants.ElevatorConstants;
import frc.robot.subsystems.ElevatorSubsystem;

/**
 * Command to move the elevator to Level 2 position.
 * 
 * <p>This command moves the elevator to the middle scoring position (Level 2).
 * It uses PID control to smoothly reach and hold the target position.
 * 
 * <p><b>For Beginners:</b> Level 2 is the middle height for scoring game pieces.
 * The elevator will automatically move to this height and stay there.
 * 
 * @author FRC Team 9569
 */
public class ElevatorL2Command extends Command {
    private final ElevatorSubsystem elevatorSubsystem;

    /**
     * Creates a new ElevatorL2Command.
     * 
     * @param elevatorSubsystem The elevator subsystem to control
     */
    public ElevatorL2Command(ElevatorSubsystem elevatorSubsystem) {
        this.elevatorSubsystem = elevatorSubsystem;
        addRequirements(elevatorSubsystem);
    }
    
    /**
     * Called once when the command is initially scheduled.
     * Sets the elevator level tracker to 2 (Level 2).
     */
    @Override
    public void initialize() {
        elevatorSubsystem.setLevel(2);
    }

    /**
     * Called repeatedly while the command is scheduled.
     * Continuously moves the elevator toward the Level 2 position.
     */
    @Override
    public void execute() {
        elevatorSubsystem.moveToPosition(ElevatorConstants.LEVEL_2_POSITION);
    }
    
    /**
     * Called once when the command ends or is interrupted.
     * Stops the elevator motors.
     * 
     * @param interrupted true if the command was interrupted
     */
    @Override
    public void end(boolean interrupted) {
        elevatorSubsystem.stop();
    }
    
    /**
     * Returns whether the command has finished.
     * 
     * @return false - command runs until interrupted
     */
    @Override
    public boolean isFinished() {
        return false;
    }
}
