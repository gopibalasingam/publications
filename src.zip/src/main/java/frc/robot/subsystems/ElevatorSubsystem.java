package frc.robot.subsystems;

import com.revrobotics.RelativeEncoder;
import com.revrobotics.spark.SparkLowLevel.MotorType;
import com.revrobotics.spark.SparkMax;

import edu.wpi.first.math.controller.ElevatorFeedforward;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants.ElevatorConstants;
import frc.robot.Constants.HardwareMap;

/**
 * Subsystem for controlling the elevator mechanism.
 * 
 * <p>The elevator can move to different height levels for scoring game pieces.
 * It uses two motors working together for stability and strength.
 * 
 * <p><b>Beginner Note:</b> A subsystem is a major component of the robot that operates independently.
 * This elevator uses PID control to reach target positions accurately.
 * 
 * <p><b>Design Pattern:</b> This class follows the Subsystem pattern from WPILib's command-based framework.
 */
public class ElevatorSubsystem extends SubsystemBase {

    private final SparkMax leftMotor;
    private final SparkMax rightMotor;
    private final RelativeEncoder leftEncoder;
    private final RelativeEncoder rightEncoder;
    private final ElevatorFeedforward feedforward;
    private final PIDController positionController;
    
    private double currentLeftPosition;
    private double currentRightPosition;
    private int currentLevel;

    /**
     * Creates a new ElevatorSubsystem.
     * 
     * <p>Initializes motors, encoders, and control systems.
     * The left motor is inverted to match the right motor's direction.
     */
    public ElevatorSubsystem() {
        leftMotor = new SparkMax(HardwareMap.ELEVATOR_MOTOR_LEFT_ID, MotorType.kBrushless);
        rightMotor = new SparkMax(HardwareMap.ELEVATOR_MOTOR_RIGHT_ID, MotorType.kBrushless);
        
        leftEncoder = leftMotor.getEncoder();
        rightEncoder = rightMotor.getEncoder();
        
        feedforward = new ElevatorFeedforward(
            ElevatorConstants.FEEDFORWARD_KS,
            ElevatorConstants.FEEDFORWARD_KG,
            ElevatorConstants.FEEDFORWARD_KV,
            ElevatorConstants.FEEDFORWARD_KA
        );
        
        positionController = new PIDController(
            ElevatorConstants.POSITION_KP,
            ElevatorConstants.POSITION_KI,
            ElevatorConstants.POSITION_KD
        );
        
        configureMotors();
        initializeEncoders();
        currentLevel = 1;
    }

    /**
     * Configures motor settings.
     * The left motor is inverted so both motors spin the same direction.
     */
    private void configureMotors() {
        leftMotor.setInverted(true);
    }

    /**
     * Initializes both encoder positions to zero.
     * Called during subsystem construction.
     */
    private void initializeEncoders() {
        leftEncoder.setPosition(0);
        rightEncoder.setPosition(0);
    }
    
    /**
     * Resets both encoder positions to zero.
     * Call this when the elevator is at its lowest physical position.
     */
    public void resetEncoders() {
        initializeEncoders();
    }

    /**
     * Sets the current elevator level for tracking.
     * 
     * @param level The level number (0 = retracted, 1-3 = scoring heights)
     */
    public void setLevel(int level) {
        this.currentLevel = level;
    }

    /**
     * Gets the current elevator level.
     * 
     * @return The current level number
     */
    public int getLevel() {
        return currentLevel;
    }

    /**
     * Moves the elevator to a target position using PID control.
     * 
     * <p><b>Beginner Note:</b> PID (Proportional-Integral-Derivative) is a control algorithm
     * that smoothly moves the elevator to the target position and holds it there.
     * 
     * @param targetPosition The desired encoder position in ticks
     */
    public void moveToPosition(double targetPosition) {
        double leftOutput = positionController.calculate(currentLeftPosition, targetPosition);
        double rightOutput = positionController.calculate(currentRightPosition, targetPosition);
        
        double leftVoltage = leftOutput * leftMotor.getBusVoltage();
        double rightVoltage = rightOutput * rightMotor.getBusVoltage();
        
        leftMotor.setVoltage(leftVoltage);
        rightMotor.setVoltage(rightVoltage);
    }

    /**
     * Gets the average position of both elevator motors.
     * 
     * @return The current position in encoder ticks
     */
    public double getPosition() {
        return (currentLeftPosition + currentRightPosition) / 2.0;
    }

    /**
     * Manually sets the elevator motor voltage.
     * 
     * <p><b>Warning:</b> This bypasses position control. Use carefully for testing only.
     * 
     * @param voltage The voltage to apply (-12.0 to +12.0 volts)
     */
    public void setVoltage(double voltage) {
        leftMotor.setVoltage(voltage);
        rightMotor.setVoltage(voltage);
    }

    /**
     * Stops both elevator motors immediately.
     */
    public void stop() {
        leftMotor.set(0);
        rightMotor.set(0);
    }

    /**
     * Periodic method called every 20ms by the scheduler.
     * Updates encoder readings and sends data to the dashboard.
     */
    @Override
    public void periodic() {
        currentLeftPosition = leftEncoder.getPosition();
        currentRightPosition = rightEncoder.getPosition();
        
        SmartDashboard.putNumber("Elevator/Current Level", currentLevel);
        SmartDashboard.putNumber("Elevator/Position", getPosition());
    }
}
