package frc.robot.subsystems;

import static edu.wpi.first.units.Units.Meters;
import static edu.wpi.first.units.Units.MetersPerSecond;
import static edu.wpi.first.units.Units.Second;

import edu.wpi.first.wpilibj.AddressableLED;
import edu.wpi.first.wpilibj.AddressableLEDBuffer;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.LEDPattern;
import edu.wpi.first.wpilibj.util.Color;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants.HardwareMap;

/**
 * Subsystem for controlling the robot's LED strip.
 * 
 * <p>This subsystem creates visual feedback using colored LED patterns.
 * It can display alliance colors, game piece status, and special effects.
 * 
 * <p><b>Beginner Note:</b> LEDs help drivers and spectators understand what
 * the robot is doing. For example:
 * <ul>
 *   <li>Green = Has game piece</li>
 *   <li>Yellow = Intaking</li>
 *   <li>Alliance color = Ready</li>
 * </ul>
 * 
 * <p><b>Design Pattern:</b> Uses the Strategy pattern with LEDPattern objects.
 */
public class LEDSubsystem extends SubsystemBase {
    
    private final AddressableLED ledStrip;
    private final AddressableLEDBuffer ledBuffer;
    private LEDPattern currentPattern;

    /**
     * Creates a new LEDSubsystem.
     * 
     * <p>Initializes the LED strip and sets it to display alliance colors by default.
     */
    public LEDSubsystem() {
        ledStrip = new AddressableLED(HardwareMap.LED_STRIP_PORT);
        ledBuffer = new AddressableLEDBuffer(HardwareMap.LED_COUNT);
        
        ledStrip.setLength(ledBuffer.getLength());
        ledStrip.setData(ledBuffer);
        ledStrip.start();
        
        initializeDefaultPattern();
    }
    
    /**
     * Initializes the default LED pattern during construction.
     */
    private void initializeDefaultPattern() {
        var alliance = DriverStation.getAlliance();
        if (alliance.isPresent()) {
            if (alliance.get() == DriverStation.Alliance.Red) {
                currentPattern = LEDPattern.gradient(LEDPattern.GradientType.kContinuous, Color.kDarkRed, Color.kOrangeRed)
                    .scrollAtAbsoluteSpeed(MetersPerSecond.of(0.6), Meters.of(1.0 / 120.0));
            } else {
                currentPattern = LEDPattern.gradient(LEDPattern.GradientType.kContinuous, Color.kCyan, Color.kDarkBlue)
                    .scrollAtAbsoluteSpeed(MetersPerSecond.of(0.6), Meters.of(1.0 / 120.0));
            }
        } else {
            currentPattern = LEDPattern.rainbow(255, 120)
                .scrollAtAbsoluteSpeed(MetersPerSecond.of(0.8), Meters.of(1.0 / 120.0));
        }
    }

    /**
     * Displays the default LED pattern based on alliance color.
     * 
     * <p>Shows a scrolling gradient in alliance colors, or rainbow if
     * alliance is unknown (like during practice mode).
     */
    public void displayDefaultPattern() {
        initializeDefaultPattern();
    }

    /**
     * Sets the LEDs to display a static rainbow pattern.
     * 
     * @param brightness The brightness level (0-255)
     * @param pixelsPerColor How many LEDs per color in the rainbow
     */
    public void setRainbow(int brightness, int pixelsPerColor) {
        currentPattern = LEDPattern.rainbow(brightness, pixelsPerColor);
    }

    /**
     * Sets the LEDs to display a scrolling rainbow pattern.
     * Good for indicating the robot is enabled but idle.
     */
    public void setRainbowScrolling() {
        currentPattern = LEDPattern.rainbow(255, 120)
            .scrollAtAbsoluteSpeed(
                MetersPerSecond.of(0.8),
                Meters.of(1.0 / 120.0)
            );
    }

    /**
     * Sets all LEDs to a single solid color.
     * 
     * <p><b>Example Uses:</b>
     * <ul>
     *   <li>Green = Has game piece</li>
     *   <li>Yellow = Intaking</li>
     *   <li>Red = Error or disabled</li>
     * </ul>
     * 
     * @param color The color to display
     */
    public void setSolidColor(Color color) {
        currentPattern = LEDPattern.solid(color);
    }

    /**
     * Sets the LEDs to blink a color on and off.
     * 
     * <p>Useful for urgent feedback like low battery or errors.
     * 
     * @param color The color to blink
     * @param periodSeconds How long for one blink cycle (on + off)
     */
    public void setBlink(Color color, double periodSeconds) {
        currentPattern = LEDPattern.solid(color).blink(Second.of(periodSeconds));
    }

    /**
     * Sets the LEDs to "breathe" a color (fade in and out).
     * 
     * <p>Creates a calm pulsing effect. Good for showing the robot is ready.
     * 
     * @param color The color to breathe
     * @param periodSeconds How long for one breath cycle
     */
    public void setBreathe(Color color, double periodSeconds) {
        currentPattern = LEDPattern.solid(color).breathe(Second.of(periodSeconds));
    }

    /**
     * Sets the LEDs to display a scrolling gradient between two colors.
     * 
     * <p>This creates a smooth color transition that moves along the strip.
     * 
     * @param color1 The first color
     * @param color2 The second color
     * @param speedMetersPerSecond How fast the gradient scrolls
     */
    public void setScrollingGradient(Color color1, Color color2, double speedMetersPerSecond) {
        currentPattern = LEDPattern.gradient(LEDPattern.GradientType.kContinuous, color1, color2)
            .scrollAtAbsoluteSpeed(
                MetersPerSecond.of(speedMetersPerSecond),
                Meters.of(1.0 / 120.0)
            );
    }

    /**
     * Turns off all LEDs.
     */
    public void turnOff() {
        currentPattern = LEDPattern.solid(Color.kBlack);
    }

    /**
     * Periodic method called every 20ms by the scheduler.
     * Updates the LED strip with the current pattern.
     */
    @Override
    public void periodic() {
        currentPattern.applyTo(ledBuffer);
        ledStrip.setData(ledBuffer);
    }
}
