package frc.robot.subsystems;

import static edu.wpi.first.units.Units.Meter;

import java.io.File;
import java.util.Optional;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;

import com.pathplanner.lib.auto.AutoBuilder;
import com.pathplanner.lib.commands.PathPlannerAuto;
import com.pathplanner.lib.config.PIDConstants;
import com.pathplanner.lib.config.RobotConfig;
import com.pathplanner.lib.controllers.PPHolonomicDriveController;
import com.pathplanner.lib.path.PathConstraints;

import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj.DriverStation;
import edu.wpi.first.wpilibj.Filesystem;
import edu.wpi.first.wpilibj.smartdashboard.Field2d;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.Commands;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import edu.wpi.first.wpilibj2.command.button.RobotModeTriggers;
import frc.robot.Constants.SwerveConstants;
import swervelib.SwerveDrive;
import swervelib.math.SwerveMath;
import swervelib.parser.SwerveParser;
import swervelib.telemetry.SwerveDriveTelemetry;
import swervelib.telemetry.SwerveDriveTelemetry.TelemetryVerbosity;

/**
 * Subsystem for controlling the swerve drive system.
 * 
 * <p>Swerve drive allows the robot to move in any direction while rotating independently.
 * This is like a car that can drive sideways! Each wheel can spin and turn separately.
 * 
 * <p><b>Beginner Note:</b> This subsystem handles:
 * <ul>
 *   <li>Field-oriented driving (forward is always away from your alliance wall)</li>
 *   <li>Vision integration for accurate positioning</li>
 *   <li>Autonomous path following</li>
 *   <li>Odometry (tracking where the robot is on the field)</li>
 * </ul>
 * 
 * <p><b>Design Pattern:</b> Facade pattern - simplifies the complex YAGSL swerve library.
 */
public class SwerveSubsystem extends SubsystemBase {

    private final SwerveDrive swerveDrive;
    private final Vision visionSubsystem;
    private final Field2d fieldDisplay;
    private final Field2d photonFieldDisplay;

    /**
     * Creates a new SwerveSubsystem.
     * 
     * <p>Loads swerve configuration from JSON files and sets up autonomous capabilities.
     * 
     * @throws RuntimeException if swerve configuration files cannot be loaded
     */
    public SwerveSubsystem() {
        SwerveDriveTelemetry.verbosity = TelemetryVerbosity.HIGH;
        
        visionSubsystem = new Vision();
        fieldDisplay = new Field2d();
        photonFieldDisplay = new Field2d();
        
        SmartDashboard.putData("Swerve/Field Display", fieldDisplay);
        SmartDashboard.putData("Swerve/Vision Display", photonFieldDisplay);
        
        File swerveDirectory = new File(Filesystem.getDeployDirectory(), "swerve");
        
        try {
            swerveDrive = new SwerveParser(swerveDirectory).createSwerveDrive(
                SwerveConstants.MAX_SPEED_METERS_PER_SECOND,
                new Pose2d(
                    new Translation2d(Meter.of(1), Meter.of(4)),
                    Rotation2d.fromDegrees(0)
                )
            );
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize swerve drive", e);
        }
        
        configureDrive();
        setupPathPlanner();
        setupAutoTriggers();
    }

    /**
     * Configures swerve drive settings.
     */
    private void configureDrive() {
        swerveDrive.setHeadingCorrection(false);
        swerveDrive.setCosineCompensator(false);
    }

    /**
     * Sets up triggers for autonomous mode.
     */
    private void setupAutoTriggers() {
        RobotModeTriggers.autonomous().onTrue(Commands.runOnce(this::zeroGyroWithAlliance));
    }

    /**
     * Gets the underlying SwerveDrive object.
     * 
     * <p><b>Warning:</b> Only use this for advanced operations.
     * 
     * @return The SwerveDrive instance
     */
    public SwerveDrive getSwerveDrive() {
        return swerveDrive;
    }

    /**
     * Drives the robot field-oriented.
     * 
     * <p><b>Beginner Note:</b> Field-oriented means "forward" on the joystick
     * is always away from your alliance wall, no matter which way the robot faces.
     * 
     * @param velocity The desired chassis speeds
     */
    public void driveFieldOriented(ChassisSpeeds velocity) {
        swerveDrive.driveFieldOriented(velocity);
    }

    /**
     * Creates a command that drives the robot field-oriented.
     * 
     * @param velocitySupplier Supplies the desired chassis speeds
     * @return A command that drives the robot
     */
    public Command driveFieldOriented(Supplier<ChassisSpeeds> velocitySupplier) {
        return run(() -> swerveDrive.driveFieldOriented(velocitySupplier.get()));
    }

    /**
     * Configures PathPlanner for autonomous path following.
     * 
     * <p><b>Beginner Note:</b> PathPlanner lets you draw paths on a field map,
     * and this code makes the robot follow those paths automatically.
     */
    private void setupPathPlanner() {
        RobotConfig config;
        try {
            config = RobotConfig.fromGUISettings();
            
            final boolean enableFeedforward = true;
            
            AutoBuilder.configure(
                swerveDrive::getPose,
                swerveDrive::resetOdometry,
                swerveDrive::getRobotVelocity,
                (speedsRobotRelative, moduleFeedForwards) -> {
                    ChassisSpeeds correctedSpeeds = new ChassisSpeeds(
                        speedsRobotRelative.vxMetersPerSecond,
                        speedsRobotRelative.vyMetersPerSecond,
                        -speedsRobotRelative.omegaRadiansPerSecond
                    );

                    if (enableFeedforward) {
                        swerveDrive.drive(
                            speedsRobotRelative,
                            swerveDrive.kinematics.toSwerveModuleStates(correctedSpeeds),
                            moduleFeedForwards.linearForces()
                        );
                    } else {
                        swerveDrive.setChassisSpeeds(speedsRobotRelative);
                    }
                },
                new PPHolonomicDriveController(
                    new PIDConstants(4.79645, 0.0, 0.0),
                    new PIDConstants(5.0, 0.0, 0.0)
                ),
                config,
                this::shouldMirrorPath,
                this
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Determines if paths should be mirrored for red alliance.
     * 
     * @return true if on red alliance, false otherwise
     */
    private boolean shouldMirrorPath() {
        var alliance = DriverStation.getAlliance();
        return alliance.isPresent() && alliance.get() == DriverStation.Alliance.Red;
    }

    /**
     * Gets a command to run an autonomous path.
     * 
     * @param pathName The name of the PathPlanner path
     * @return A command that follows the path
     */
    public Command getAutonomousCommand(String pathName) {
        return new PathPlannerAuto(pathName);
    }

    /**
     * Resets the gyro heading to zero.
     */
    public void zeroGyro() {
        swerveDrive.zeroGyro();
    }

    /**
     * Gets the robot's current heading.
     * 
     * @return The current heading as a Rotation2d
     */
    public Rotation2d getHeading() {
        return getPose().getRotation();
    }

    /**
     * Zeros the gyro and sets initial pose based on alliance.
     * 
     * <p>For red alliance, the robot starts facing 180 degrees.
     */
    public void zeroGyroWithAlliance() {
        if (isRedAlliance()) {
            zeroGyro();
            resetOdometry(new Pose2d(getPose().getTranslation(), Rotation2d.fromDegrees(180)));
        } else {
            zeroGyro();
        }
    }

    /**
     * Resets odometry using vision data if available.
     */
    public void resetOdometryWithVision() {
        Optional<Pose2d> visionPose = visionSubsystem.getPose2dR();
        visionPose.ifPresent(swerveDrive::resetOdometry);
    }

    /**
     * Checks if the robot is on the red alliance.
     * 
     * @return true if red alliance, false otherwise
     */
    private boolean isRedAlliance() {
        var alliance = DriverStation.getAlliance();
        return alliance.isPresent() && alliance.get() == DriverStation.Alliance.Red;
    }

    /**
     * Gets the robot's current pose on the field.
     * 
     * @return The current Pose2d (position and rotation)
     */
    public Pose2d getPose() {
        return swerveDrive.getPose();
    }

    /**
     * Resets the robot's odometry to a specific pose.
     * 
     * @param initialPose The pose to reset to
     */
    public void resetOdometry(Pose2d initialPose) {
        swerveDrive.resetOdometry(initialPose);
    }

    /**
     * Creates a command to drive using joystick inputs.
     * 
     * @param translationX Forward/backward speed supplier
     * @param translationY Left/right speed supplier
     * @param angularRotation Rotation speed supplier
     * @return A command that drives the robot
     */
    public Command driveCommand(
            DoubleSupplier translationX,
            DoubleSupplier translationY,
            DoubleSupplier angularRotation) {
        
        return run(() -> {
            swerveDrive.drive(
                SwerveMath.scaleTranslation(
                    new Translation2d(
                        translationX.getAsDouble() * swerveDrive.getMaximumChassisVelocity(),
                        translationY.getAsDouble() * swerveDrive.getMaximumChassisVelocity()
                    ),
                    0.8
                ),
                Math.pow(angularRotation.getAsDouble(), 3) * swerveDrive.getMaximumChassisAngularVelocity(),
                true,
                false
            );
        });
    }

    /**
     * Creates a command to drive to a specific pose on the field.
     * 
     * <p><b>Beginner Note:</b> This uses pathfinding to automatically
     * navigate around obstacles and reach the target position.
     * 
     * @param targetPose The pose to drive to
     * @return A command that drives to the pose
     */
    public Command driveToPose(Pose2d targetPose) {
        PathConstraints constraints = new PathConstraints(
            2.0, 2.0,
            10.0, Units.degreesToRadians(720)
        );

        return AutoBuilder.pathfindToPose(
            targetPose,
            constraints,
            edu.wpi.first.units.Units.MetersPerSecond.of(0)
        );
    }

    /**
     * Periodic method called every 20ms by the scheduler.
     * Updates odometry with vision data and sends telemetry to dashboard.
     */
    @Override
    public void periodic() {
        updateModuleTelemetry();
        updateVisionMeasurements();
        updateFieldDisplay();
    }

    /**
     * Updates telemetry for individual swerve modules.
     */
    private void updateModuleTelemetry() {
        var modules = swerveDrive.getModules();
        for (int i = 0; i < modules.length; i++) {
            SmartDashboard.putNumber("Swerve/Module " + (i + 1) + " Angle", 
                modules[i].getAbsolutePosition());
        }
    }

    /**
     * Integrates vision measurements into odometry.
     * 
     * <p><b>Beginner Note:</b> Cameras can see AprilTags on the field and
     * help correct the robot's position estimate for better accuracy.
     */
    private void updateVisionMeasurements() {
        Optional<Pose2d> rightCameraPose = visionSubsystem.getPose2dR();
        Optional<Double> rightCameraTimestamp = visionSubsystem.getTimestampR();
        
        Optional<Pose2d> leftCameraPose = visionSubsystem.getPose2dL();
        Optional<Double> leftCameraTimestamp = visionSubsystem.getTimestampL();
        
        boolean hasRightVision = false;
        boolean hasLeftVision = false;
        
        if (rightCameraPose.isPresent() && rightCameraTimestamp.isPresent()) {
            swerveDrive.addVisionMeasurement(rightCameraPose.get(), rightCameraTimestamp.get());
            photonFieldDisplay.setRobotPose(rightCameraPose.get());
            hasRightVision = true;
        }
        
        if (leftCameraPose.isPresent() && leftCameraTimestamp.isPresent()) {
            swerveDrive.addVisionMeasurement(leftCameraPose.get(), leftCameraTimestamp.get());
            photonFieldDisplay.setRobotPose(leftCameraPose.get());
            hasLeftVision = true;
        }
        
        SmartDashboard.putBoolean("Swerve/Right Camera Active", hasRightVision);
        SmartDashboard.putBoolean("Swerve/Left Camera Active", hasLeftVision);
    }

    /**
     * Updates the field display with current robot position.
     */
    private void updateFieldDisplay() {
        Pose2d currentPose = swerveDrive.getPose();
        fieldDisplay.setRobotPose(currentPose);
        
        SmartDashboard.putNumber("Swerve/Robot X", currentPose.getX());
        SmartDashboard.putNumber("Swerve/Robot Y", currentPose.getY());
        SmartDashboard.putNumber("Swerve/Robot Heading", currentPose.getRotation().getDegrees());
    }
}
