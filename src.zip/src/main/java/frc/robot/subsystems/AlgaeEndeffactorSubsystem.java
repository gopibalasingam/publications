package frc.robot.subsystems;

import com.revrobotics.spark.SparkLowLevel.MotorType;
import com.revrobotics.spark.SparkMax;

import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.wpilibj.DutyCycleEncoder;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;
import edu.wpi.first.wpilibj2.command.SubsystemBase;
import frc.robot.Constants.AlgaeConstants;
import frc.robot.Constants.HardwareMap;

/**
 * Subsystem for controlling the algae intake and pivot mechanism.
 * 
 * <p>This subsystem manages two motors:
 * <ul>
 *   <li>Intake motor: Pulls algae in or pushes it out</li>
 *   <li>Pivot motor: Moves the intake arm to different angles</li>
 * </ul>
 * 
 * <p><b>Beginner Note:</b> The pivot uses an absolute encoder (DutyCycleEncoder) which
 * remembers its position even after the robot is powered off. This is important for
 * safety - the robot knows where the arm is immediately when turned on.
 * 
 * <p><b>Design Pattern:</b> Uses PID control for precise pivot positioning.
 */
public class AlgaeEndeffactorSubsystem extends SubsystemBase {
    
    private final SparkMax intakeMotor;
    private final SparkMax pivotMotor;
    private final DutyCycleEncoder pivotEncoder;
    private final PIDController pivotController;

    /**
     * Creates a new AlgaeEndeffactorSubsystem.
     * 
     * <p>Initializes motors, encoder, and PID controller for the pivot.
     */
    public AlgaeEndeffactorSubsystem() {
        intakeMotor = new SparkMax(HardwareMap.ALGAE_MOTOR_ID, MotorType.kBrushless);
        pivotMotor = new SparkMax(HardwareMap.ALGAE_PIVOT_MOTOR_ID, MotorType.kBrushless);
        pivotEncoder = new DutyCycleEncoder(HardwareMap.ALGAE_ENCODER_PORT);
        
        pivotController = new PIDController(
            AlgaeConstants.PIVOT_KP,
            AlgaeConstants.PIVOT_KI,
            AlgaeConstants.PIVOT_KD
        );
    }

    /**
     * Gets the current pivot angle with zero offset applied.
     * 
     * <p><b>Beginner Note:</b> We subtract a zero offset because the encoder's
     * "zero" position might not match our mechanical "zero" position.
     * 
     * @return The current angle in rotations (0.0 to 1.0)
     */
    private double getCurrentPivotAngle() {
        return pivotEncoder.get() - AlgaeConstants.ENCODER_ZERO_OFFSET;
    }

    /**
     * Moves the pivot to a target angle using PID control.
     * 
     * <p><b>Beginner Note:</b> PID smoothly moves the pivot to the target angle.
     * The negative sign inverts the motor direction to match the mechanism.
     * 
     * @param targetAngle The desired angle in rotations (0.0 to 1.0)
     */
    public void movePivotToAngle(double targetAngle) {
        double currentAngle = getCurrentPivotAngle();
        double output = pivotController.calculate(currentAngle, targetAngle);
        double voltage = output * pivotMotor.getBusVoltage() * -1;
        
        pivotMotor.setVoltage(voltage);
        
        SmartDashboard.putNumber("Algae/Target Angle", targetAngle);
        SmartDashboard.putNumber("Algae/Current Angle", currentAngle);
        SmartDashboard.putNumber("Algae/Pivot Output", voltage);
    }

    /**
     * Manually sets the pivot motor voltage.
     * 
     * <p><b>Warning:</b> This bypasses position control. Use for testing only.
     * 
     * @param voltage The voltage to apply (-12.0 to +12.0 volts)
     */
    public void setPivotVoltage(double voltage) {
        pivotMotor.setVoltage(voltage);
    }

    /**
     * Stops the pivot motor immediately.
     */
    public void stopPivot() {
        pivotMotor.setVoltage(0);
    }
    
    /**
     * Alias for stopPivot() - stops the pivot motor.
     * Kept for compatibility with existing commands.
     */
    public void algaePivotStop() {
        stopPivot();
    }
    
    /**
     * Alias for movePivotToAngle() - moves pivot to target position.
     * Kept for compatibility with existing commands.
     * 
     * @param targetAngle The desired angle in rotations
     */
    public void algaeSetPoint(double targetAngle) {
        movePivotToAngle(targetAngle);
    }
    
    /**
     * Alias for setIntakeSpeed() - sets intake motor voltage.
     * Kept for compatibility with existing commands.
     * 
     * @param voltage The voltage to apply
     * @deprecated Use setIntakeSpeed() instead
     */
    @Deprecated
    public void setSpeed(double voltage) {
        setIntakeSpeed(voltage);
    }

    /**
     * Sets the intake motor speed.
     * 
     * <p><b>Beginner Note:</b> 
     * <ul>
     *   <li>Negative voltage = intake (pull in)</li>
     *   <li>Positive voltage = eject (push out)</li>
     * </ul>
     * 
     * @param voltage The voltage to apply (-12.0 to +12.0 volts)
     */
    public void setIntakeSpeed(double voltage) {
        intakeMotor.setVoltage(voltage);
    }

    /**
     * Runs the intake to pull in algae.
     */
    public void intake() {
        setIntakeSpeed(AlgaeConstants.INTAKE_VOLTAGE);
    }

    /**
     * Runs the intake to eject algae.
     */
    public void eject() {
        setIntakeSpeed(AlgaeConstants.EJECT_VOLTAGE);
    }

    /**
     * Stops the intake motor immediately.
     */
    public void stopIntake() {
        intakeMotor.setVoltage(0);
    }

    /**
     * Periodic method called every 20ms by the scheduler.
     * Sends encoder data to the dashboard for debugging.
     */
    @Override
    public void periodic() {
        SmartDashboard.putNumber("Algae/Encoder Angle", getCurrentPivotAngle());
    }
}
